function callURLs() {
    $.ajax({
        type: 'GET',
        url: apiurl,
        dataType: "json"
    }).done(function(data) {
      $('#myTextarea').append(JSON.stringify(data, undefined, 4))
    });
}