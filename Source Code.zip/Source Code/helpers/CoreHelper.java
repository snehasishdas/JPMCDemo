package com.jpmc.demo.core.helpers;

import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.json.jcr.JsonItemWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import java.io.StringWriter;
import java.util.Iterator;

public class CoreHelper {
    private static Logger LOG = LoggerFactory.getLogger(CoreHelper.class);


    public static JSONObject resourceToJSONObject(final Resource resource) throws RepositoryException, JSONException {
        JSONObject jsonObject = null;

            final Node node = resource.adaptTo(Node.class);
            final StringWriter stringWriter = new StringWriter();
            final JsonItemWriter jsonWriter = new JsonItemWriter(null);


            /* Get JSON with no limit to recursion depth. */
            jsonWriter.dump(node, stringWriter, -1);
            jsonObject = new JSONObject(stringWriter.toString());
            removeUnwantedProperties(jsonObject);

        return jsonObject;
    }

    public static JSONArray resourceToJSONArray(final ResourceResolver resolver, final Resource resource) throws RepositoryException, JSONException {
        JSONArray resultsJsonArr = new JSONArray();
            final Node parentNode = resource.adaptTo(Node.class);
            final JsonItemWriter jsonWriter = new JsonItemWriter(null);
            NodeIterator nodeIterator= parentNode.getNodes();
            while(nodeIterator.hasNext()){
                Node node = nodeIterator.nextNode();
                JSONObject input = new JSONObject();
                input.put(node.getName(), nodeToJSONObject(resolver, node));
                resultsJsonArr.put(input);
            }
        return resultsJsonArr;
    }

    public static JSONObject nodeToJSONObject(final ResourceResolver resolver, Node node)throws RepositoryException, JSONException {
        JSONObject j = new JSONObject();
            Property property = node.getProperty("sling:resourceType");
            if(property != null){
                if(property.getValue().getString().equalsIgnoreCase("cq/experience-fragments/editor/components/experiencefragment")){
                    Property p = node.getProperty("fragmentPath");
                    Resource expFragmentResource = resolver.getResource(p.getValue().getString()+"/jcr:content/root");
                    j = CoreHelper.resourceToJSONObject(expFragmentResource);
                    // adding Object key as the component node name
                }else{
                    j = CoreHelper.resourceToJSONObject(resolver.getResource(node.getPath()));
                }
            }
        return j;
    }

    public static void removeUnwantedProperties(JSONObject jsonObject) throws JSONException {
        if(jsonObject.has("jcr:lastModified")){
            jsonObject.remove("jcr:lastModified");
        }
        if(jsonObject.has("jcr:lastModifiedBy")){
            jsonObject.remove("jcr:lastModifiedBy");
        }
        if(jsonObject.has("jcr:primaryType")){
            jsonObject.remove("jcr:primaryType");
        }
        if(jsonObject.has("sling:resourceType")){
            jsonObject.remove("sling:resourceType");
        }
        if(jsonObject.has("jcr:created")){
            jsonObject.remove("jcr:created");
        }
        if(jsonObject.has("jcr:createdBy")){
            jsonObject.remove("jcr:createdBy");
        }
        //
        Iterator<String> keys = jsonObject.keys();
        while(keys.hasNext()) {
            String key = keys.next();
            if (jsonObject.get(key) instanceof JSONObject) {
                removeUnwantedProperties(jsonObject.getJSONObject(key));
            }
        }
    }

    public static JSONObject getErrorMessage(SlingHttpServletResponse response) throws RepositoryException, JSONException{
        JSONObject jsonObject = new JSONObject("{\"message\":\"Could not find valid page/ component resource\"}");
        //throw new HttpResponseException();
        //response.setStatus(500);
        return jsonObject;
    }
}
