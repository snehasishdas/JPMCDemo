package com.jpmc.demo.core.schedulers;

import com.adobe.aemds.guide.utils.JcrResourceConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.annotations.*;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.SimpleCredentials;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 
 */
@Designate(ocd=SimpleScheduledTask.Config.class)
@Component(service=Runnable.class, immediate = true)
public class SimpleScheduledTask implements Runnable {

    @ObjectClassDefinition(name="JPMCDemo Content Review scheduled task",
                           description = "Simple demo for cron-job like task with properties")
    public static @interface Config {

        @AttributeDefinition(name = "Enabled", description = "Enable Scheduler", type = AttributeType.BOOLEAN)
        boolean serviceEnabled() default false;

        @AttributeDefinition(name = "Expression", type = AttributeType.STRING)
        String scheduler_expression() default "0 0/1 * * * ?";

        @AttributeDefinition(name = "Concurrent task",
                             description = "Whether or not to schedule this task concurrently")
        boolean scheduler_concurrent() default false;

        @AttributeDefinition(name = "Scheduler name", description = "Scheduler name", type = AttributeType.STRING)
        public String schedulerName() default "OSGi Scheduler Example";

        @AttributeDefinition(name = "Content Path",
                             description = "Content Paths to search for review metadata")
        public String[] contentPath() default {};
    }

    private static Logger LOG = LoggerFactory.getLogger(SimpleScheduledTask.class);

    @Reference
    private QueryBuilder queryBuilder;

    @Reference
    ResourceResolverFactory resourceResolverFactory;

    @Reference
    private WorkflowService workflowService;

    @Reference
    private SlingRepository repository;

    @Reference
    private Scheduler scheduler;
    private int schedulerID;
    private String[] contentPath;
    private boolean enabled;
    final static String ISO8601_DATE = ("YYYY-MM-DDTHH:mm:ss.SSSZ");
    
    @Override
    public void run() {
        ArrayList<Resource> rsearchesult = new ArrayList<Resource>();
        try {
            LOG.info("-----------> Enabled " + enabled);
            

            if (enabled) {

                Map<String, String> params = new HashMap<String, String>();
                params.put("group.p.or", "true");
                int i = 1;
                for (String path : contentPath) {
                    params.put("group." + i + "_path", path);
                    i++;
                }


                params.put("relativedaterange.property","jcr:content/reviewTime");
                params.put("relativedaterange.lowerBound", "-30s");
                params.put("relativedaterange.lowerOperation", "=");
                params.put("relativedaterange.upperBound", "30s");
                params.put("relativedaterange.upperOperation", "=");

                params.put("type", "cq:Page");
                params.put("p.limit", "-1");
                params.put("p.hits", "full");

                Session session = repository.loginAdministrative(null);
                ResourceResolver resolver = this.getResourceResolver(session);
                
                Query query = queryBuilder.createQuery(PredicateGroup.create(params), session);
                SearchResult resualt = query.getResult();
                
                for(Hit hit : resualt.getHits()){                    
                    rsearchesult.add(hit.getResource());                 
                }

                if(rsearchesult.size()>0) {
                    this.startWorkflow(rsearchesult);
                }

            }
        }catch( Exception e){
            LOG.info("Exception "+e.getMessage());
            e.getStackTrace();
        }
    }

    @Activate
    protected void activate(final Config config) {
        schedulerID = config.schedulerName().hashCode();
        contentPath = config.contentPath();
        enabled = config.serviceEnabled();
    }

    @Modified
    protected void modified(final Config config) {
        removeScheduler();
        schedulerID = config.schedulerName().hashCode(); // update schedulerID
        enabled = config.serviceEnabled();
        //addScheduler(config);
    }

    @Deactivate
    protected void deactivate(final Config config) {
        scheduler.unschedule(String.valueOf(schedulerID));
    }

    private void removeScheduler() {
        LOG.info("Removing Scheduler Job '{}'", schedulerID);
        scheduler.unschedule(String.valueOf(schedulerID));
    }

    private void addScheduler(final Config config) {
        if (config.serviceEnabled()) {
            ScheduleOptions sopts = scheduler.EXPR(config.scheduler_expression());
            sopts.name(String.valueOf(schedulerID));
            sopts.canRunConcurrently(false);
            scheduler.schedule(this, sopts);
            enabled = config.serviceEnabled();
            LOG.info("Scheduler added succesfully");
        } else {
            enabled = config.serviceEnabled();
            LOG.info("OSGi Scheduler Example is Disabled, no scheduler job created");
        }
    }

    public void startWorkflow(ArrayList<Resource> resualts) throws WorkflowException, RepositoryException {

        LOG.info("----STARTING WORKFLOW-----");

        for(Resource re : resualts){

            String initiator = re.getValueMap().get("cq:lastModifiedBy", String.class);
            if(null == initiator){
                initiator = re.getValueMap().get("jcr:createdBy", String.class);
            }


            Session usersession = repository.impersonateFromService("workflow-process-service", new SimpleCredentials(initiator, "".toCharArray()), null);
            final WorkflowSession workflowSession = workflowService.getWorkflowSession(usersession);
            final String aem63WorkflowModelPath = "/etc/workflow/models/jpmcdemo---content-review-workflow/jcr:content/model";
            final WorkflowModel workflowModel = workflowSession.getModel(aem63WorkflowModelPath);
            final String payloadPath = re.getPath();

            final WorkflowData workflowData = workflowSession.newWorkflowData("JCR_PATH", payloadPath);

            final Map<String, Object> workflowMetadata = new HashMap<>();
            workflowMetadata.put("workflowTitle", "Auto Initiated Content Validation - Paylod: "+payloadPath);
            Workflow w = workflowSession.startWorkflow(workflowModel, workflowData, workflowMetadata);

        }
    }

    private ResourceResolver getResourceResolver(Session session) throws LoginException {
        return resourceResolverFactory.getResourceResolver(Collections.<String, Object>singletonMap(JcrResourceConstants.AUTHENTICATION_INFO_SESSION,
                session));
    }

}
