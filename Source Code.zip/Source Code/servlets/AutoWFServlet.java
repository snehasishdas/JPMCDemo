package com.jpmc.demo.core.servlets;

import com.adobe.aemds.guide.utils.JcrResourceConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;
import jxl.Sheet;
import jxl.Workbook;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.SimpleCredentials;
import javax.servlet.Servlet;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.rmi.ServerException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Component(service= Servlet.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=JPMC Auto Workflow Trigger Servlet",
                "sling.servlet.methods=" + HttpConstants.METHOD_GET,
                "sling.servlet.paths="+ "/services/autoTriggerService"
        })
@Designate( ocd = AutoWFServlet.Configs.class)
public class AutoWFServlet extends SlingAllMethodsServlet {

    private static Logger LOG = LoggerFactory.getLogger(AutoWFServlet.class);

    @ObjectClassDefinition(name="JPMC Auto Workflow Trigger Servlet",
            description = "JPMC Auto Workflow Trigger Servlet")
    public @interface Configs {
        @AttributeDefinition(name = "Property page.path", description = "Page path", type = AttributeType.STRING)
        String page_path() default "";
    }

    @Reference
    private SlingRepository repository;

    @Reference
    private QueryBuilder queryBuilder;

    @Reference
    ResourceResolverFactory resourceResolverFactory;

    @Reference
    private WorkflowService workflowService;

    private String pagePath;

    private ResourceResolver resourceResolver;


   @Activate
    public void activate(ComponentContext ctx, AutoWFServlet.Configs config){

       LOG.info("Activating AutoWFServlet");
       pagePath = config.page_path();
    }

    @Deactivate
    public void deactivate(ComponentContext ctx){
        LOG.info("Deactivating AutoWFServlet");
    }

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
        LOG.info("***********************GET**************************");
        try
        {
            resourceResolver = request.getResourceResolver();
            this.startWorkflow();

        }catch (Exception e) {
            e.printStackTrace();
            LOG.info(e.getMessage());
        }
    }

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {

        LOG.info("***********************POST**************************");

        try
        {
            resourceResolver = request.getResourceResolver();
            this.startWorkflow();

        }catch (Exception e) {
            e.printStackTrace();
            LOG.info(e.getMessage());
        }



    }

    public void startWorkflow() throws WorkflowException, RepositoryException, Exception{

        ArrayList<String> rsearchesult = new ArrayList<String>();
        String initiator = "digitalauthor1";
        Session usersession = repository.impersonateFromService("workflow-process-service", new SimpleCredentials(initiator, "".toCharArray()), null);
        final WorkflowSession workflowSession = workflowService.getWorkflowSession(usersession);
        final String aem63WorkflowModelPath = "/etc/workflow/models/-jpmcdemo-contentapprovalworkflow/jcr:content/model";

        // Get the Workflow Model object
        final WorkflowModel workflowModel = workflowSession.getModel(aem63WorkflowModelPath);



        final Map<String, Object> workflowMetadata = new HashMap<>();
        workflowMetadata.put("workflowTitle", "Auto Initiated Content Approval Workflow");

        rsearchesult = this.searchFragments(pagePath,rsearchesult);

        for(String path:rsearchesult){
            final WorkflowData workflowData = workflowSession.newWorkflowData("JCR_PATH", path);
            Workflow w = workflowSession.startWorkflow(workflowModel, workflowData, workflowMetadata);
        }

    }


    private ArrayList<String> searchFragments(String rootPath, ArrayList<String> rsearchesult) throws Exception{

        Map<String, String> params = new HashMap<String, String>();
        params.put("group.p.or", "true");
        params.put("group.1_path", rootPath);
        params.put("type", "cq:Page");
        params.put("property", "jcr:content/sling:resourceType");
        params.put("property.value", "JPMCDemo/components/structure/xfpage");
        params.put("property.operation", "equals");
        params.put("p.limit", "-1");
        params.put("p.hits", "full");

        Session session = repository.loginAdministrative(null);
        ResourceResolver resolver = this.getResourceResolver(session);
        Query query = queryBuilder.createQuery(PredicateGroup.create(params), session);
        SearchResult resualt = query.getResult();
        for(Hit hit : resualt.getHits()){
            rsearchesult.add(hit.getResource().getPath());
        }
        return rsearchesult;

    }
    private ResourceResolver getResourceResolver(Session session) throws LoginException {
        return resourceResolverFactory.getResourceResolver(Collections.<String, Object>singletonMap(JcrResourceConstants.AUTHENTICATION_INFO_SESSION,
                session));
    }
}
