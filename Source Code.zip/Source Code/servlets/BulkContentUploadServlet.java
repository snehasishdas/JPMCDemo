package com.jpmc.demo.core.servlets;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.WCMException;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;
import jxl.read.biff.BiffException;
import org.apache.jackrabbit.commons.JcrUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.SimpleCredentials;
import javax.servlet.Servlet;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.rmi.ServerException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

import jxl.*;

@Component(service= Servlet.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=Bulk Content Upload Servlet",
                "sling.servlet.methods=" + HttpConstants.METHOD_POST,
                "sling.servlet.paths="+ "/services/BulkUploadService"
        })
public class BulkContentUploadServlet extends SlingAllMethodsServlet {

    private static Logger LOG = LoggerFactory.getLogger(BulkContentUploadServlet.class);

    private static String EXP_FRAGMENT_TEMPLATE = "/libs/cq/experience-fragments/components/experiencefragment/template";
    private static String XF_PAGE_TEMPLATE = "/conf/JPMCDemo/settings/wcm/templates/demo-experience-fragment-web-variation";


    @Reference
    private ResourceResolverFactory resolverFactory;

    @Reference
    private SlingRepository repository;

    @Reference
    private WorkflowService workflowService;

    private Session session;

    @Activate
    public void activate(ComponentContext ctx){
        LOG.info("Activating BulkContentUploadServlet");
    }

    @Deactivate
    public void deactivate(ComponentContext ctx){
        LOG.info("Deactivating BulkContentUploadServlet");
    }

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {

    }

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {

        LOG.info("***********************POST**************************");

        try
        {
            final boolean isMultipart = org.apache.commons.fileupload.servlet.ServletFileUpload.isMultipartContent(request);
            PrintWriter out = null;
            LOG.info("GET THE STREAM");
            InputStream stream = null;
            String strategy = "";

            if (isMultipart) {


                final java.util.Map<String, org.apache.sling.api.request.RequestParameter[]> params = request.getRequestParameterMap();
                for (final java.util.Map.Entry<String, org.apache.sling.api.request.RequestParameter[]> pairs : params.entrySet()) {
                    final String k = pairs.getKey();

                    final org.apache.sling.api.request.RequestParameter[] pArr = pairs.getValue();
                    final org.apache.sling.api.request.RequestParameter param = pArr[0];

                    if(k.equalsIgnoreCase("our-file")){
                        stream = param.getInputStream();
                    }else if(k.equalsIgnoreCase("uploadstrategy")){
                        strategy = param.getString();
                    }
                }

                readSpreadSheet(stream, strategy);

            }
        }

        catch (Exception e) {
            e.printStackTrace();
            LOG.info(e.getMessage());
        }

    }

    private void readSpreadSheet(InputStream is, String strategy) throws Exception {

        Workbook workbook = Workbook.getWorkbook(is);
        LOG.info("Reading Workbook");
        Sheet sheet = workbook.getSheet(0);
        int numCol = sheet.getColumns();
        int numRows = sheet.getRows();

        for(int i=0; i<numRows; i++){
            String pagePath = "";
            String pageTitle = "";
            String pageComponent = "";
            HashMap<String,String> props = new HashMap<String,String>();
            String propName="";
            String propVal = "";
            for(int j=0; j<numCol; j++){
                if(j==0){
                    pagePath = sheet.getCell(j,i+1).getContents();
                }else if(j==1){
                    pageTitle = sheet.getCell(j,i+1).getContents();
                }else if(j==2){
                    pageComponent = sheet.getCell(j,i+1).getContents();
                }else{
                    String tempVal = sheet.getCell(j,i+1).getContents();
                    if(tempVal.length()>0) {
                        if (j % 2 == 0) {
                            propVal = tempVal;
                            props.put(propName,propVal);
                        } else {
                            propName = tempVal;
                        }
                    }
                }
            }
            if(strategy.equalsIgnoreCase("create")) {
                Page generatedPage = createOrUpdateContent(pagePath, pageTitle, pageComponent, props);
                this.startWorkflow(generatedPage.getPath());
            }else if(strategy.equalsIgnoreCase("delete")) {
                deleteContent(pagePath);
            }
        }
    }

    private void deleteContent(final String pagePath) throws Exception{
        LOG.info("------------DELETE-------------");
        ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
        session = resourceResolver.adaptTo(Session.class);
        PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
        Page fragment = pageManager.getPage(pagePath);
        if(null != fragment){
            pageManager.delete(fragment,false, true);
        }

    }

    private Page createOrUpdateContent(final String pagePath, final String pageTitle, final String pageComponent, final HashMap<String, String> props) throws Exception {

        Page varientPage = null;

        ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
        session = resourceResolver.adaptTo(Session.class);
        PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
        if (pageManager != null) {
            varientPage = createOrUpdatePage(pagePath,pageTitle, pageComponent, props, pageManager, session);
            return varientPage;
        }

        return varientPage;

    }

    private Page createOrUpdatePage(final String pagePath, final String pageTitle, final String pageComponent, final HashMap<String, String> props, final PageManager pageManager, Session session) throws Exception {
        String name = StringUtils.substringAfterLast(pagePath, "/");
        String basepath = StringUtils.substringBeforeLast(pagePath, "/");
        Page fragment = null;
        if(null == pageManager.getPage(pagePath)) {
            fragment = pageManager.create(basepath, name, EXP_FRAGMENT_TEMPLATE, pageTitle, true);
        }

        String varientPath = pagePath+"/"+name;
        Page varient = pageManager.getPage(varientPath);
        if(null == varient) {
            varient = pageManager.create(pagePath,name, XF_PAGE_TEMPLATE, pageTitle, true);
            if(null != varient){
                String tags[]={"experience-fragments:variation/web"};
                Node jcrNode = varient.getContentResource().adaptTo(Node.class);
                jcrNode.setProperty("cq:xfMasterVariation", true);
                jcrNode.setProperty("cq:xfVariantType", "web");
                jcrNode.setProperty("cq:tags", tags);
                session.save();
                //
                Node comp = jcrNode.getNode("root").addNode(pageComponent);
                comp.setProperty("sling:resourceType", "JPMCDemo/components/content/"+pageComponent);
                addUpdatedProperties(comp,props,session);
                session.save();
            }
        }else{
            Node jcrNode = varient.getContentResource().adaptTo(Node.class);
            Node root = jcrNode.getNode("root");
            Node comp = null;
            if(root.hasNode(pageComponent)){
                comp = root.getNode(pageComponent);
            }else{
                comp = root.addNode(pageComponent);
                comp.setProperty("sling:resourceType", "JPMCDemo/components/content/"+pageComponent);
            }
            session.save();
            addUpdatedProperties(comp,props,session);
        }

        return varient;
    }

    private void addUpdatedProperties(Node node, final HashMap<String, String> props, Session session)throws Exception{
        for(String key: props.keySet()){
            if(StringUtils.contains(key, "/")){
                String[] nodeNames = key.split("/");
                String newPropName = nodeNames[nodeNames.length-1];
                Node newNode = node;
                for(int i=0; i<nodeNames.length-1;i++){
                    if(newNode.hasNode(nodeNames[i])) {
                        newNode = newNode.getNode(nodeNames[i]);
                    }else{
                        newNode = newNode.addNode(nodeNames[i]);
                    }
                    addSlingResourceType(newNode, session);
                    session.save();
                }
                newNode.setProperty(newPropName, props.get(key));
            }else {
                
                node.setProperty(key, props.get(key));
            }
        }
        session.save();
    }

    private void addSlingResourceType(Node node, Session session)throws Exception{
        if(node.getName().equalsIgnoreCase("image")){
            node.setProperty("sling:resourceType","foundation/components/image");
        }else if(node.getName().equalsIgnoreCase("text")){
            node.setProperty("sling:resourceType","core/wcm/components/text/v1/text");
            node.setProperty("textIsRich","true");

        }else if(node.getName().equalsIgnoreCase("list")){
            node.setProperty("sling:resourceType","core/wcm/components/list/v1/list");
        }
        session.save();
    }

    public void startWorkflow(String pagePath) throws WorkflowException, RepositoryException, Exception{

        String initiator = "digitalauthor1";
        Session usersession = repository.impersonateFromService("workflow-process-service", new SimpleCredentials(initiator, "".toCharArray()), null);
        final WorkflowSession workflowSession = workflowService.getWorkflowSession(usersession);
        final String aem63WorkflowModelPath = "/etc/workflow/models/-jpmcdemo-contentapprovalworkflow/jcr:content/model";
        final WorkflowModel workflowModel = workflowSession.getModel(aem63WorkflowModelPath);

        final Map<String, Object> workflowMetadata = new HashMap<>();
        workflowMetadata.put("workflowTitle", "Auto Initiated Content Approval Workflow");
        final WorkflowData workflowData = workflowSession.newWorkflowData("JCR_PATH", pagePath);
        Workflow w = workflowSession.startWorkflow(workflowModel, workflowData, workflowMetadata);

    }
}
