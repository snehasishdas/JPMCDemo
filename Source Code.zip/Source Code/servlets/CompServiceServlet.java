package com.jpmc.demo.core.servlets;

import com.day.cq.wcm.api.PageManager;
import com.jpmc.demo.core.helpers.CoreHelper;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;

@Component(service= Servlet.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=Component Service Demo Servlet",
                "sling.servlet.methods=" + HttpConstants.METHOD_GET,
                "sling.servlet.paths="+ "/services/v2/componentService",
                "sling.servlet.extensions=" + "json"
        })
public class CompServiceServlet extends SlingSafeMethodsServlet {

        private static Logger LOG = LoggerFactory.getLogger(CompServiceServlet.class);
        private ResourceResolver resolver;
        private JSONObject object;


        @Activate
        public void activate(ComponentContext ctx){
                LOG.info("Activating ContentServiceServlet");
        }

        @Deactivate
        public void deactivate(ComponentContext ctx){
                LOG.info("Deactivating ContentServiceServlet");
        }


        @Override
        protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {

                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.setHeader("X-Content-Type-Options","nosniff");
                PrintWriter writer = response.getWriter();
                String requestPath = request.getParameter("path");

                try {
                        resolver = request.getResourceResolver();
                        if(requestPath != null){
                                Resource resource = resolver.getResource(requestPath);
                                Node rootNode = resource.adaptTo(Node.class);
                                object = getNodeDetailsAsJson(rootNode, response);
                        }  else {
                                object = CoreHelper.getErrorMessage(response);
                        }
                        writer.write(object.toString());

                } catch ( Exception e) {
                        LOG.info("Could not create JSON", e);
                        try {
                                object = CoreHelper.getErrorMessage(response);
                                writer.write(object.toString());
                        }catch(RepositoryException | JSONException ex){
                                LOG.info("Could not create JSON", e);
                        }
                }

        }

        private JSONObject getNodeDetailsAsJson(Node node, SlingHttpServletResponse response) throws Exception{
                JSONObject i = new JSONObject();
                if(node.getName().equalsIgnoreCase("rep:policy") && node.getProperty("jcr:primaryType").getValue().getString().equalsIgnoreCase("rep:acl")) {
                     //
                }else if(node.hasProperty("jcr:primaryType") && node.getProperty("jcr:primaryType").getValue().getString().equalsIgnoreCase("cq:page") && node.hasNode("jcr:content")){
                        String resourceType = node.getNode("jcr:content").getProperty("sling:resourceType").getValue().getString();
                        if(resourceType.equalsIgnoreCase("cq/experience-fragments/components/experiencefragment")){
                                if (node.hasNodes()) {
                                        NodeIterator nodes = node.getNodes();
                                        while (nodes.hasNext()) {
                                                Node n = nodes.nextNode();
                                                if (n.getName().equalsIgnoreCase("jcr:content")){
                                                        // do nothing
                                                }else{
                                                        JSONObject j = new JSONObject();
                                                        i = j.put(n.getName(),getNodeDetailsAsJson(n, response));
                                                        i.put("title", node.getNode("jcr:content").getProperty("jcr:title").getValue().getString());
                                                }

                                        }

                                }
                        }if(resourceType.equalsIgnoreCase("JPMCDemo/components/structure/xfpage")){
                                Resource resource = resolver.getResource(node.getPath() + "/jcr:content/root");
                                if( null != resource) {
                                        i = CoreHelper.resourceToJSONObject(resource);
                                }else{
                                        i = CoreHelper.getErrorMessage(response);
                                }
                        }
                }else {
                        if (node.hasNodes()) {
                                JSONArray array = new JSONArray();
                                NodeIterator nodes = node.getNodes();
                                while (nodes.hasNext()) {
                                        Node n = nodes.nextNode();
                                        JSONObject test = getNodeDetailsAsJson(n, response);
                                        if(test.length()>0) {
                                                array.put(test);
                                        }
                                }
                                JSONObject newobj = i.put(node.getName(), array);
                                if (node.hasProperty("jcr:title")) {
                                        newobj.put("title", node.getProperty("jcr:title").getValue().getString());
                                }

                        } else {
                                JSONObject j = new JSONObject();
                                if (node.hasProperty("jcr:title")) {
                                        j.put("title", node.getProperty("jcr:title").getValue().getString());
                                }
                                i.put(node.getName(), j);
                        }
                }

                return i;
        }
}
