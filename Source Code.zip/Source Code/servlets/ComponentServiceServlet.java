package com.jpmc.demo.core.servlets;

import com.jpmc.demo.core.helpers.CoreHelper;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;

@Component(service= Servlet.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=Component Service Demo Servlet",
                "sling.servlet.methods=" + HttpConstants.METHOD_GET,
                "sling.servlet.paths="+ "/services/componentService",
                "sling.servlet.extensions=" + "json"
        })
public class ComponentServiceServlet extends SlingSafeMethodsServlet {

        private static Logger LOG = LoggerFactory.getLogger(ComponentServiceServlet.class);
        private ResourceResolver resolver;
        private JSONObject object;


        @Activate
        public void activate(ComponentContext ctx){
                LOG.info("Activating ContentServiceServlet");
        }

        @Deactivate
        public void deactivate(ComponentContext ctx){
                LOG.info("Deactivating ContentServiceServlet");
        }


        @Override
        protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {

                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.setHeader("X-Content-Type-Options","nosniff");
                PrintWriter writer = response.getWriter();
                String requestPath = request.getParameter("path");

                try {
                        resolver = request.getResourceResolver();
                        if(requestPath != null){
                                Resource resource = resolver.getResource(requestPath + "/jcr:content/root");
                                if( null != resource) {
                                        object = CoreHelper.resourceToJSONObject(resource);
                                }else{
                                        object = CoreHelper.getErrorMessage(response);
                                }

                        }  else {
                                object = CoreHelper.getErrorMessage(response);
                        }
                        writer.write(object.toString());

                } catch ( RepositoryException | JSONException e) {
                        LOG.info("Could not create JSON", e);
                        try {
                                object = CoreHelper.getErrorMessage(response);
                                writer.write(object.toString());
                        }catch(RepositoryException | JSONException ex){
                                LOG.info("Could not create JSON", e);
                        }
                }

        }
}
