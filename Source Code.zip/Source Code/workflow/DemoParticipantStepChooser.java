package com.jpmc.demo.core.workflow;
import com.adobe.aemds.guide.utils.JcrResourceConstants;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.HistoryItem;
import com.day.cq.workflow.exec.ParticipantStepChooser;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.User;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import java.io.StringWriter;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


@Component(immediate=true, service = ParticipantStepChooser.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=JPMC: Dynamic Approver Participant Step",
                ParticipantStepChooser.SERVICE_PROPERTY_LABEL+"=JPMC: Dynamic Approver Participant Step"
        })
public class DemoParticipantStepChooser implements ParticipantStepChooser {

    private static Logger LOG = LoggerFactory.getLogger(DemoParticipantStepChooser.class);

    @Reference
    ResourceResolverFactory resourceResolverFactory;

    @Activate
    public void activate(ComponentContext ctx){
        LOG.info("Activating DemoParticipantStepChooser");
    }

    @Deactivate
    public void deactivate(ComponentContext ctx){
        LOG.info("Deactivating DemoParticipantStepChooser");
    }

    @Override
    public String getParticipant(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {

        String assignedGroupName = null;
        ResourceResolver resourceResolver = null;

        try {
            String param = metaDataMap.get("PROCESS_ARGS", String.class).toString();
            if(param.equalsIgnoreCase("initiator")){
                assignedGroupName = workItem.getWorkflow().getInitiator();
                return assignedGroupName;
            }else if(param.equalsIgnoreCase("group")){
                resourceResolver = getResourceResolver(workflowSession.getSession());
                List<HistoryItem> historyList = workflowSession.getHistory(workItem.getWorkflow());
                String initiator = workItem.getWorkflow().getInitiator();
                final UserManager usermanager = resourceResolver.adaptTo(UserManager.class);
                final User initiatorUser = (User) usermanager.getAuthorizable(initiator);
                Iterator<Group> iterator = initiatorUser.memberOf();
                while(iterator.hasNext()){
                    Group group = iterator.next();
                    if(group.getID().contains("-author-lob-")){
                        assignedGroupName = group.getID().replace("author", "reviewer");
                    }else{
                        assignedGroupName = "admin";
                    }
                    return assignedGroupName;
                }
            }else{
                assignedGroupName = "admin";
                return assignedGroupName;
            }

        }catch(Exception e){
            LOG.info("Exception occurred in DemoParticipantStepChooser ", e);
        }
        return assignedGroupName;
    }

    private ResourceResolver getResourceResolver(Session session) throws LoginException {
        return resourceResolverFactory.getResourceResolver(Collections.<String, Object>singletonMap(JcrResourceConstants.AUTHENTICATION_INFO_SESSION,
                session));
    }

}
