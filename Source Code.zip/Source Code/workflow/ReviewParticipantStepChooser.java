package com.jpmc.demo.core.workflow;
import com.adobe.aemds.guide.utils.JcrResourceConstants;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.HistoryItem;
import com.day.cq.workflow.exec.ParticipantStepChooser;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.User;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.*;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.Session;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


@Component(immediate=true, service = ParticipantStepChooser.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=JPMC: Dynamic Reviewer Participant Step",
                ParticipantStepChooser.SERVICE_PROPERTY_LABEL+"=JPMC: Dynamic Reviewer Participant Step"
        })
public class ReviewParticipantStepChooser implements ParticipantStepChooser {

    private static Logger LOG = LoggerFactory.getLogger(ReviewParticipantStepChooser.class);

    @Reference
    ResourceResolverFactory resourceResolverFactory;

    @Activate
    public void activate(ComponentContext ctx){
        LOG.info("Activating ReviewParticipantStepChooser");
    }

    @Deactivate
    public void deactivate(ComponentContext ctx){
        LOG.info("Deactivating ReviewParticipantStepChooser");
    }

    @Override
    public String getParticipant(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {

        String assignedGroupName = null;
        ResourceResolver resourceResolver = null;

        try {
            String initiator = "";
            resourceResolver = getResourceResolver(workflowSession.getSession());
            String pagePath = (String) workItem.getWorkflowData().getPayload();
            Resource resource = resourceResolver.getResource(pagePath+"/jcr:content");
            ValueMap vMap = resource.getValueMap();
            if(vMap.containsKey("cq:lastModifiedBy")){
                initiator = vMap.get("cq:lastModifiedBy", String.class);
            }
            final UserManager usermanager = resourceResolver.adaptTo(UserManager.class);
            final User initiatorUser = (User) usermanager.getAuthorizable(initiator);
            Iterator<Group> iterator = initiatorUser.memberOf();
            while(iterator.hasNext()){
                Group group = iterator.next();
                if(group.getID().contains("-author-lob-")){
                    assignedGroupName = group.getID();
                }
            }
            if(null == assignedGroupName)
            {
                assignedGroupName = "admin";
            }
            return assignedGroupName;


        }catch(Exception e){
            LOG.info("Exception occurred in ReviewParticipantStepChooser ", e);
        }
        return assignedGroupName;
    }

    private ResourceResolver getResourceResolver(Session session) throws LoginException {
        return resourceResolverFactory.getResourceResolver(Collections.<String, Object>singletonMap(JcrResourceConstants.AUTHENTICATION_INFO_SESSION,
                session));
    }

}
